package v1.Interface;

/**
 * @(#) Command.java
 */

public interface Command {

	void execute();

}
