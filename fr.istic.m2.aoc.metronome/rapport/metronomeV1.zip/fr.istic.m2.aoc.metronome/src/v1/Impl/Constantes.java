package v1.Impl;

public class Constantes {

	public static final int MIN_MESURE = 2;
	public static final int MAX_MESURE = 7;
	
	
}
