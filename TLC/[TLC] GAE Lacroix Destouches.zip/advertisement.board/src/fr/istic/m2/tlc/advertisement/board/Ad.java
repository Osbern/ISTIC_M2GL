package fr.istic.m2.tlc.advertisement.board;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.google.appengine.api.datastore.Key;
import com.google.appengine.api.datastore.KeyFactory;

@Entity
public class Ad implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 9128218619170128225L;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Key key;
	
	private String title;
	private int price;
	private Date date;
	
	public Ad(String title, int price, Date d) {
		this.title = title;
		this.price = price;
		date = d;
	}
	public Ad() {
		
	}
	public void setKey(Key key) {
		this.key = key;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getName() {
		return title;
	}
	public int getPrice() {
		return price;
	}
	public Date getDate() {
		return date;
	}
	public String getKey(){
		return KeyFactory.keyToString(key);
	}
	public String toHTML() {
		String buffer = "<tr>";
		buffer += "<td>" + title + "</td>";
		buffer += "<td>" + price + " �</td>";
		buffer += "<td>" + date.toString() + "</td>";
		buffer += "<td><a href=\"Delete.jsp?id=" + key.getId() + "\">X</a>"; 
		buffer += "</tr>";
		return buffer;
	}
}
