package fr.istic.m2.tlc.advertisement.board;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.google.appengine.api.datastore.KeyFactory;
import com.google.appengine.api.search.Cursor;
import com.google.appengine.api.search.Document;
import com.google.appengine.api.search.Field;
import com.google.appengine.api.search.GetRequest;
import com.google.appengine.api.search.GetResponse;
import com.google.appengine.api.search.Index;
import com.google.appengine.api.search.IndexSpec;
import com.google.appengine.api.search.Query;
import com.google.appengine.api.search.QueryOptions;
import com.google.appengine.api.search.Results;
import com.google.appengine.api.search.ScoredDocument;
import com.google.appengine.api.search.SearchException;
import com.google.appengine.api.search.SearchServiceFactory;
import com.google.appengine.api.search.SortExpression;
import com.google.appengine.api.search.SortOptions;

public class AdService {

	public static Index getIndex() {
		IndexSpec indexSpec = IndexSpec.newBuilder().setName("adindex").build();
		return SearchServiceFactory.getSearchService().getIndex(indexSpec);
	}

	private static final EntityManagerFactory emf = Persistence
			.createEntityManagerFactory("transactions-optional");
	public static final EntityManager em = emf.createEntityManager();

	public static Ad addAd(String title, int price) {
		Date d = new Date(System.currentTimeMillis());
		Ad a = new Ad(title, price, d);
		em.getTransaction().begin();
		em.persist(a);
		em.getTransaction().commit();

		Document doc = Document.newBuilder()
				.addField(Field.newBuilder().setName("id").setText(a.getKey()))
				.addField(Field.newBuilder().setName("title").setText(title))
				.addField(Field.newBuilder().setName("price").setNumber(price))
				.addField(Field.newBuilder().setName("date").setDate(d))
				.build();
		getIndex().put(doc);

		// TODO
		// https://developers.google.com/appengine/docs/java/search/overview

		return a;
	}

	public static List<Ad> getAds() {
		TypedQuery<Ad> q = em.createQuery("SELECT a FROM " + Ad.class.getName()
				+ " a", Ad.class);
		List<Ad> res = q.getResultList();
		return res;
	}

	public static List<Ad> searchAds(String title, String min, String max) {
		List<Ad> res = new ArrayList<Ad>();
		int myMin;
		int myMax;
		// v�rification des param�tres
		try {
			myMin = Integer.parseInt(min);
		} catch (Throwable t) {
			myMin = 0;
		}
		try {
			myMax = Integer.parseInt(max);
		} catch (Throwable t) {
			myMax = Integer.MAX_VALUE;
		}
		String queryString = "price >= " + myMin + " AND price <= " + myMax;
		if(title != null && !title.equals("")){
			queryString = queryString + " title:"+title;
		}
		
		Results<ScoredDocument> results = findDocuments(queryString, 20, Cursor
				.newBuilder().build());

		if (results != null) {
			for (ScoredDocument sd : results) {
				Ad a = new Ad();
				for (Field f : sd.getFields()) {
					if (f.getName().equals("id")) {
						a.setKey(KeyFactory.stringToKey(f.getText()));
					} else if (f.getName().equals("title")) {
						a.setTitle(f.getText());
					} else if (f.getName().equals("price")) {
						a.setPrice(f.getNumber().intValue());
					}else if (f.getName().equals("date")) {
						a.setDate(f.getDate());
					}
				}
				res.add(a);
			}
		}
		return res;
	}

	public static Results<ScoredDocument> findDocuments(String queryString,
			int limit, Cursor cursor) {
		try {
	
			Query query = Query.newBuilder().build(queryString);
			return getIndex().search(query);
		} catch (SearchException e) {
			System.err.println("Search request with query " + queryString
					+ " failed");
			return null;
		}
	}

	public static List<Ad> old_searchAds(String title, String min, String max) {

		int myMin, myMax;
		Map<Integer, Collection<Ad>> res = new HashMap<Integer, Collection<Ad>>();

		// v�rification des param�tres
		try {
			myMin = Integer.parseInt(min);
		} catch (Throwable t) {
			myMin = 0;
		}
		try {
			myMax = Integer.parseInt(max);
		} catch (Throwable t) {
			myMax = Integer.MAX_VALUE;
		}

		// requete sur les prix (min/max)
		TypedQuery<Ad> q1 = em.createQuery(
				"SELECT a FROM " + Ad.class.getName()
						+ " a WHERE price BETWEEN " + myMin + " AND " + myMax,
				Ad.class);

		// stockage des scores pour cette requete

		res.put(100, q1.getResultList());

		if (title != null && !title.equals("")) {
			String[] keyWords = title.split("\\s");
			int points = 100 / keyWords.length;

			Map<Integer, Collection<Ad>> toModify = new HashMap<Integer, Collection<Ad>>();

			for (String keyword : keyWords) {
				toModify.clear();

				for (Entry<Integer, Collection<Ad>> e : res.entrySet()) {
					for (Ad a : e.getValue()) {
						if (a.getName().contains(keyword)) {
							if (!toModify.containsKey(e.getKey())) {
								toModify.put(e.getKey(), new ArrayList<Ad>());
							}

							toModify.get(e.getKey()).add(a);
							e.getValue().remove(a);
						}
					}
				}
				for (Entry<Integer, Collection<Ad>> e : toModify.entrySet()) {
					int newKey = e.getKey() + points;
					if (!res.containsKey(newKey)) {
						res.put(newKey, new ArrayList<Ad>());
					}
					res.get(newKey).addAll(e.getValue());
				}
			}

		}

		// if (title != null) {
		// TypedQuery<Ad> q = em.createQuery(
		// "SELECT a FROM " + Ad.class.getName()
		// + " a WHERE title like \"" + title + "%\"",
		// Ad.class);
		// res = q.getResultList();
		// }

		ArrayList<Ad> ret = new ArrayList<Ad>();
		return ret;
	}

	public static void delete(String id) {
		TypedQuery<Ad> q = em.createQuery("SELECT a FROM " + Ad.class.getName()
				+ " a WHERE  key = " + id, Ad.class);
		List<Ad> lrm = q.getResultList();
		if (lrm.size() == 1) {
			em.getTransaction().begin();
			em.remove(lrm.get(0));
			em.getTransaction().commit();

			try {
				while (true) {
					List<String> docIds = new ArrayList<String>();
					// Return a set of document IDs.
					GetRequest request = GetRequest.newBuilder()
							.setReturningIdsOnly(true).build();
					GetResponse<Document> response = getIndex().getRange(
							request);
					if (response.getResults().isEmpty()) {
						break;
					}
					for (Document doc : response) {
						docIds.add(doc.getId());
					}
					getIndex().delete(docIds);
				}
			} catch (RuntimeException e) {

				System.err.println("Failed to delete documents");
			}

		} else {
			System.err.println("CA MARCHE PAS!");
		}
	}

}

class searchResult implements Comparable<searchResult> {
	int score;
	Collection<Ad> results;

	public searchResult() {
		score = 0;
		results = new ArrayList<Ad>();
	}

	searchResult(int score, Collection<Ad> results) {
		this();
		this.score = score;
		this.results.addAll(results);
	}

	@Override
	public int compareTo(searchResult o) {
		if (score < o.score) {
			return -1;
		} else if (score > o.score) {
			return 1;
		}
		return 0;
	}
}
