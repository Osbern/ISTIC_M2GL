package gae.measurements.main;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			String url = "http://isticmoujon.appspot.com/adv/Ad.jsp";
			for (int i = 0; i < 500; i++) {
				int start = (int) System.currentTimeMillis();
				URL oracle = new URL(url + "?title=Add" + i + "&price=" + i);
		        BufferedReader in = new BufferedReader(new InputStreamReader(oracle.openStream()));
		        in.close();
		        int time = (int) (System.currentTimeMillis() - start);
		        System.out.println("" + time);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
